package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;


import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    //ID voor bluetooth
    static final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    //De button voor licht aan doen
    Button knp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //aangemaakte button
        knp = findViewById(R.id.button);

        //bluetooth adapter voor de bluetooth connectie
        BluetoothAdapter bltAdp = BluetoothAdapter.getDefaultAdapter();

        //toestemming bluetooth connectie
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
        }
        System.out.println(bltAdp.getBondedDevices());

        //Bluetooth apparaat (stoplicht) ophalen met macadress
        BluetoothDevice hc05 = bltAdp.getRemoteDevice("98:D3:61:FD:35:1E");
        System.out.println(hc05.getName());

        //Verbinden door drukken op knop op de tablet
        knp.setOnClickListener(e->{
            BluetoothSocket bltSocket = null;
            try {
                bltSocket = hc05.createRfcommSocketToServiceRecord(mUUID);
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            for (int teller = 0; teller < 3; teller++) {
                if (!bltSocket.isConnected()){
                    try {
                        System.out.println(bltSocket);
                        bltSocket.connect();
                        System.out.println(bltSocket.isConnected());

                    } catch (IOException a) {
                        a.printStackTrace();
                    }
                    teller++;
                }
            }
            //De gegevens ophalen outputstream en naar apparaat sturen
            try {
                OutputStream outputStream = bltSocket.getOutputStream();
                outputStream.write(48);

            } catch (IOException i) {
                i.printStackTrace();
            }

            try {
                bltSocket.close();
                System.out.println(bltSocket.isConnected());

            } catch (IOException i) {
                i.printStackTrace();
            }
        });
    }
}